package com.cg.cart.dao;

public interface ProductDao {

}

package com.cg.cart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cart.beans.Product;
import com.cg.cart.beans.Wishlist;
import com.cg.cart.service.CustService;
//import com.cg.cart.service.ProdService;


@RestController
public class WishController {

	@Autowired
	CustService ser;

/*	@Autowired
	ProdService pSer;*/
	  
	
	@PostMapping("/addProductDetails")
    public List<Product> addProductDetails(@RequestBody Product product) {
        return ser.addProductDetails(product);
    }
   
/*	@PostMapping(value = "/addtoWishlist/{id}")
		public void addToWishlist(@RequestBody Product pro,@PathVariable int id) {
				 ser.addToWishlist(pro,id);
				 
	}*/

	@PostMapping("/addtoWishlist/{id}")
	public List<Wishlist> addtoWishlist(@RequestBody Product pro,@PathVariable int id)
	{
		return ser.addToWishlist(pro,id);
	}
	  
	@RequestMapping(value = "/{id}/Wishlist")
	  	public List<Wishlist> getAllItems(@PathVariable int id) {
	  		return ser.getAllItems(id);
	  	}
	  
	@PostMapping(value = "/{id}/addtocart")
			public void addToCart(@RequestBody Product pro ,@PathVariable int id) {
				 ser.addToCart(pro,id);
			}
	  	 
	@PostMapping(value = "/{id}/buyNow")
		public void buyNow(@RequestBody Product pro, @PathVariable int id) {
			 ser.buyNow(pro,id);
		}
	    	  
	@DeleteMapping(value = "/{id}/{pid}/removefromwishlist")
	  	public void removeFromWishlist(@PathVariable int id,@PathVariable int pid) {
	  		 ser.removeFromWishlist(id,pid);
	  	}
	  
	@DeleteMapping(value = "/{id}/{pid}/removefromcart")
	  	public void removeFromCart(@PathVariable int id,@PathVariable int pid) {
		 
		 ser.removeFromCart(id,pid);
	}
	  
}
package com.cg.cart.service;

public interface IProdService {

}

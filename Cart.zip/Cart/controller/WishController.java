package com.cg.cart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.cart.beans.Product;
import com.cg.cart.beans.Wishlist;
import com.cg.cart.service.CustService;
import com.cg.cart.service.ProdService;


public class WishController {

	@Autowired
	CustService ser;
	@Autowired
	ProdService pSer;

	 @RequestMapping(value = "/login/{username}/{password}")
	  	public int  lo(@PathVariable String username,@PathVariable String password) {
	  		return ser.loginByUsername(username, password);
	  	}
	
	  
	  @RequestMapping(value = "/{id}/addtoWishlist", method = RequestMethod.POST)
			public void addToWishlist(@RequestBody Product pro,@PathVariable int id) {
				 ser.addToWishlist(pro,id);
			}
	  
	  	  @RequestMapping(value = "/{id}/Wishlist")
	  	public List<Wishlist> getAllItems(@PathVariable int id) {
	  		return ser.getAllItems(id);
	  	}
	  
	  	 @RequestMapping(value = "/{id}/addtocart", method = RequestMethod.POST)
			public void addToCart(@RequestBody Product pro ,@PathVariable int id) {
				 ser.addToCart(pro,id);
			}
	  	 
	  @RequestMapping(value = "/{id}/buyNow", method = RequestMethod.POST)
		public void buyNow(@RequestBody Product pro, @PathVariable int id) {
			 ser.buyNow(pro,id);
		}
	  
	  
	  @DeleteMapping(value = "/{id}/{pid}/removefromwishlist")
	  	public void removeFromWishlist(@PathVariable int id,@PathVariable int pid) {
	  		 ser.removeFromWishlist(id,pid);
	  	}
	  
	  @DeleteMapping(value = "/{id}/{pid}/removefromcart")
	  	public void removeFromCart(@PathVariable int id,@PathVariable int pid) {
		 
		 ser.removeFromCart(id,pid);
	}
	  
}

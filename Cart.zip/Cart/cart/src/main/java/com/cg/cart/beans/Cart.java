package com.cg.cart.beans;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Cart {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int cart_id;
	public int prod_id;
	public String prod_name;
//	public String prod_img_link;
//	public String prod_desc;
	public double prod_price;
	public int cust_id;
	public int getCart_id() {
		return cart_id;
	}
	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}
	public int getCust_id() {
		return cust_id;
	}
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}

	public Cart() {
		super();
	}
	public int getProd_id() {
		return cart_id;
	}
	public void setProd_id(int cart_id) {
		this.cart_id = cart_id;
	}
	public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	/*public String getProd_img_link() {
		return prod_img_link;
	}
	public void setProd_img_link(String prod_img_link) {
		this.prod_img_link = prod_img_link;
	}
	public String getProd_desc() {
		return prod_desc;
	}
	public void setProd_desc(String prod_desc) {
		this.prod_desc = prod_desc;
	}*/
	public double getProd_price() {
		return prod_price;
	}
	public void setProd_price(double prod_price) {
		this.prod_price = prod_price;
	}
	@Override
	public String toString() {
		return "Cart [cart_id=" + cart_id + ", prod_id=" + prod_id + ", prod_name=" + prod_name + ", prod_price="
				+ prod_price + ", cust_id=" + cust_id + "]";
	}

	
	

}

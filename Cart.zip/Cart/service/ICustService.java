package com.cg.cart.service;

import java.util.List;

import com.cg.cart.beans.Product;
import com.cg.cart.beans.Wishlist;

public interface ICustService {
	public int loginByUsername(String username, String password);
	public List<Wishlist> getAllItems(int id);
	public void addToWishlist(Product pro, int id);
	public void buyNow(Product pro, int id);
	public void addToCart(Product pro, int id);
}

package com.cg.cart.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.cart.beans.Wishlist;



@Repository
public interface WishlistDao extends JpaRepository<Wishlist, Integer> {
	@Query(value="SELECT * FROM Wishlist WHERE cust_id=:u",nativeQuery=true)
	List<Wishlist> findAll(@Param("u") Integer id);

	@Query(value="DELETE FROM Wishlist WHERE cust_id=:s AND prod_id=:u ",nativeQuery=true)
	void deleteByImg_link(@Param("s") int id,@Param("u") int id1);
}

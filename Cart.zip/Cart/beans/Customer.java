package com.cg.cart.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="custo123")
public class Customer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int cust_id;
	public String uName;
	public String pwd;
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	




	public int getCust_id() {
		return cust_id;
	}

	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
}

package com.cg.cart.service;

import java.util.List;

import com.cg.cart.beans.Product;
import com.cg.cart.beans.Wishlist;

public class CustService {

	public int loginByUsername(String username, String password) {
		// TODO Auto-generated method stub
		return 0;
	}

	public List<Wishlist> getAllItems(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void addToWishlist(Product pro, int id) {
		// TODO Auto-generated method stub
		
	}

	public void buyNow(Product pro, int id) {
		// TODO Auto-generated method stub
		
	}

	public void removeFromWishlist(int id, int pid) {
		// TODO Auto-generated method stub
		
	}

	public void removeFromCart(int id, int pid) {
		// TODO Auto-generated method stub
		
	}

	public void addToCart(Product pro, int id) {
		// TODO Auto-generated method stub
		
	}

}

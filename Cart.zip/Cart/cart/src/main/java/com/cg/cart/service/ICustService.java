package com.cg.cart.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.cg.cart.beans.Product;
import com.cg.cart.beans.Wishlist;

public interface ICustService {
	//public int loginByUsername(String username, String password) ;
	//public void addToWishlist(Product pro, int id);
	public List<Wishlist> addToWishlist(Product pro, int id);
	public List<Wishlist> getAllItems(int id);
	public void addToCart(Product pro, int id);
  	public void removeFromCart(@PathVariable int id,@PathVariable int pid) ;
}

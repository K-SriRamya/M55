package com.cg.cart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cart.beans.Cart;
import com.cg.cart.beans.Invoice;
import com.cg.cart.beans.Product;
import com.cg.cart.beans.Wishlist;
import com.cg.cart.dao.CartDao;
import com.cg.cart.dao.CustDao;
import com.cg.cart.dao.InvoiceDao;
import com.cg.cart.dao.ProductDao;
import com.cg.cart.dao.WishlistDao;
@Service

public class CustService implements ICustService {

	@Autowired
	CustDao dao;
	@Autowired
	CartDao cartDao;
	@Autowired
	WishlistDao wishlistDao;
	@Autowired
	InvoiceDao invoicedao;
	@Autowired
	ProductDao pDao;
	
/*
	@Override
	public void addToWishlist(Product pro, int id) {

		System.out.println(id);
		Wishlist wishlist = new Wishlist();
		wishlist.setCust_id(id);
		wishlist.setProd_id(pro.getProd_id());
	//	wishlist.setProd_desc(pro.getProd_desc());
	//	wishlist.setProd_img_link(pro.getProd_img_link());
		wishlist.setProd_name(pro.getProd_name());
		wishlist.setProd_price(pro.getProd_price());
		wishlistDao.save(wishlist);

	}*/

	@Override
	public List<Wishlist> getAllItems(int id) {
		return wishlistDao.findAll(id);
	}


	public void removeFromWishlist(int id, int pid) {
	//	wishlistDao.deleteByImg_link(id, pid);
		wishlistDao.deleteById(id);
	}

	@Override
	public void addToCart(Product pro, int id) {
		System.out.println(id);
		System.out.println(pro);
		Cart c = new Cart();
		c.setCust_id(id);
		//
		c.setProd_id(pro.getProd_id());
//		c.setProd_desc(pro.getProd_desc());
//		c.setProd_img_link(pro.getProd_img_link());
		c.setProd_name(pro.getProd_name());
		c.setProd_price(pro.getProd_price());
		System.out.println(c);
		cartDao.save(c);		
	}

	@Override
	public void removeFromCart(int id, int pid) {
		//cartDao.deleteByImg_link(id, pid);
		cartDao.deleteById(id);
		
	}

	public void buyNow(Product pro, int id) {
		System.out.println(pro);
		System.out.println(id);
		Invoice inv = new Invoice();
		inv.setCust_id(id);
		inv.setProd_id(pro.getProd_id());
		System.out.println(inv.getProd_id());
	//	inv.setProd_desc(pro.getProd_desc());
	//	inv.setProd_img_link(pro.getProd_img_link());
		inv.setProd_name(pro.getProd_name());
		inv.setProd_price(pro.getProd_price());
		System.out.println(inv);

		invoicedao.save(inv);

	}

	public List<Product> addProductDetails(Product product) {
		pDao.save(product);
	        return pDao.findAll();
	}


	public List<Wishlist> addToWishlist(Product pro, int id) {
		System.out.println(id);
		Wishlist wishlist = new Wishlist();
		wishlist.setCust_id(id);
		wishlist.setProd_id(pro.getProd_id());
	//	wishlist.setProd_desc(pro.getProd_desc());
	//	wishlist.setProd_img_link(pro.getProd_img_link());
		wishlist.setProd_name(pro.getProd_name());
		wishlist.setProd_price(pro.getProd_price());
		wishlistDao.save(wishlist);
		return wishlistDao.findAll();
	}

	

}
